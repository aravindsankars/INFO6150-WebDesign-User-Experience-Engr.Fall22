<!DOCTYPE> : Defines the document type

<html> : Defines the root of an HTML document

<head> : Contains information for the document

<title> : Defines a title for the document

<link> : Defines the relationship between a document
         and an external resource (most used to link to style sheets)

<body> : Defines the document's body

<img> : Defines an image

<h1>,<h2>,<h3> : Defines HTML headings

<a> : Defines a hyperlink

<div> : Defines a section in a document

<ul> : Defines an unordered list

<li> : Defines a list item

<b> : Defines bold text

<header> : Defines a header for a document or section

<form> : Defines an HTML form for user input

<label> : Defines a label for an <input> element

<meter> : Defines an input control

<span> : Defines a section in a document

<iframe> : Defines an inline frame

<br> : Defines a single line break

<footer> : Defines a footer for a document or section

----------------------------------------------------------------------------

I have used span tag for different colors for logo,name as well as 
for footer to match the background.

Put the background image style display as contain so that the
same background gets repeated for the section and hence it is 
clear as well.

With the border parameters, changed the shape of my picture.

Used h# tags according to how I wanted each sentence to be like.

The ways of contact has been defined with images of each symbol.

Use of very few colors to maintain the theme of the page.

Each certificate depicted with a screenshot of itself in 
certificates' gallery.

Used meter tag for each skill.
  